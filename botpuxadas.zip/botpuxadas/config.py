import nest_asyncio
nest_asyncio.apply()

from telethon import TelegramClient, events
import asyncio

api_id = '21565881'
api_hash = 'a23b90cfae48fae93a61423dc7c5fa7e'
group_username = 'Wanderccfuzilconsultas' # Substitua '@nome_do_grupo' pelo nome de usuário do grupo

