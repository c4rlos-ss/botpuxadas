// Inclua a biblioteca Ably
const Ably = require('ably');

// Autentique o cliente e estabeleça uma conexão
const ably = new Ably.Realtime('DvEMhg.5UWyaw:adq5B_oItUhoFROoaqxVNbVXjKItiNI_me9mX3NIKQo');

// Conecte-se ao canal 'cadu'
const channel = ably.channels.get('cadu');

// Adicione um ouvinte de mensagens no canal
channel.subscribe('cadu', (msg) => {
    console.log('Mensagem recebida:', msg.data);
});

ably.connection.once('connected', () => {
    console.log('Conectado ao Ably e ouvindo mensagens no canal "cadu"!');
});
